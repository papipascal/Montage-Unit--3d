// EquipmentCatalog.cpp
#include "EquipmentCatalog.h"
#include "PipelineSystem.h"
#include "Engine/World.h"

TArray<FEquipmentData> UEquipmentCatalog::GetEquipmentByType(EEquipmentType Type) const
{
    TArray<FEquipmentData> Result;

    for (const FEquipmentData& Equipment : AvailableEquipment)
    {
        if (Equipment.EquipmentType == Type)
        {
            Result.Add(Equipment);
        }
    }

    return Result;
}

FEquipmentData UEquipmentCatalog::GetEquipmentByName(const FString& Name) const
{
    for (const FEquipmentData& Equipment : AvailableEquipment)
    {
        if (Equipment.EquipmentName.Equals(Name, ESearchCase::IgnoreCase))
        {
            return Equipment;
        }
    }

    // Retourner un équipement par défaut si non trouvé
    return FEquipmentData();
}

TArray<FEquipmentData> UEquipmentCatalog::GetAllPumps() const
{
    return GetEquipmentByType(EEquipmentType::Pump);
}

TArray<FEquipmentData> UEquipmentCatalog::GetAllPressureVessels() const
{
    return GetEquipmentByType(EEquipmentType::PressureVessel);
}

// ========== Equipment Manager Subsystem ==========

void UEquipmentManagerSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);
    
    PlacedEquipment.Empty();
    PlacedPipelines.Empty();

    UE_LOG(LogTemp, Log, TEXT("Equipment Manager Subsystem Initialized"));
}

void UEquipmentManagerSubsystem::Deinitialize()
{
    // Nettoyer tous les équipements et pipelines
    for (AIndustrialEquipmentBase* Equipment : PlacedEquipment)
    {
        if (Equipment)
        {
            Equipment->Destroy();
        }
    }

    for (APipelineSystem* Pipeline : PlacedPipelines)
    {
        if (Pipeline)
        {
            Pipeline->Destroy();
        }
    }

    PlacedEquipment.Empty();
    PlacedPipelines.Empty();

    Super::Deinitialize();
}

AIndustrialEquipmentBase* UEquipmentManagerSubsystem::SpawnEquipmentFromCatalog(const FString& EquipmentName, const FVector& Location)
{
    if (!DefaultCatalog)
    {
        UE_LOG(LogTemp, Error, TEXT("No default catalog set"));
        return nullptr;
    }

    UWorld* World = GetWorld();
    if (!World)
    {
        return nullptr;
    }

    FEquipmentData EquipmentData = DefaultCatalog->GetEquipmentByName(EquipmentName);
    
    if (EquipmentData.EquipmentName.IsEmpty())
    {
        UE_LOG(LogTemp, Warning, TEXT("Equipment not found in catalog: %s"), *EquipmentName);
        return nullptr;
    }

    // Spawn l'équipement
    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

    AIndustrialEquipmentBase* NewEquipment = World->SpawnActor<AIndustrialEquipmentBase>(
        AIndustrialEquipmentBase::StaticClass(),
        Location,
        FRotator::ZeroRotator,
        SpawnParams
    );

    if (NewEquipment)
    {
        NewEquipment->InitializeFromData(EquipmentData);
        NewEquipment->SetPlacementMode(true);
        PlacedEquipment.Add(NewEquipment);

        UE_LOG(LogTemp, Log, TEXT("Spawned equipment: %s"), *EquipmentName);
    }

    return NewEquipment;
}

void UEquipmentManagerSubsystem::RemoveEquipment(AIndustrialEquipmentBase* Equipment)
{
    if (!Equipment)
    {
        return;
    }

    // Retirer toutes les connexions de pipelines liées
    TArray<APipelineSystem*> PipelinesToRemove;
    for (APipelineSystem* Pipeline : PlacedPipelines)
    {
        if (Pipeline && (Pipeline->StartEquipment == Equipment || Pipeline->EndEquipment == Equipment))
        {
            PipelinesToRemove.Add(Pipeline);
        }
    }

    for (APipelineSystem* Pipeline : PipelinesToRemove)
    {
        RemovePipeline(Pipeline);
    }

    // Retirer l'équipement
    PlacedEquipment.Remove(Equipment);
    Equipment->Destroy();

    UE_LOG(LogTemp, Log, TEXT("Removed equipment"));
}

APipelineSystem* UEquipmentManagerSubsystem::CreatePipeline(EPipeDiameter Diameter, EConnectionType Type)
{
    UWorld* World = GetWorld();
    if (!World)
    {
        return nullptr;
    }

    FActorSpawnParameters SpawnParams;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

    APipelineSystem* NewPipeline = World->SpawnActor<APipelineSystem>(
        APipelineSystem::StaticClass(),
        FVector::ZeroVector,
        FRotator::ZeroRotator,
        SpawnParams
    );

    if (NewPipeline)
    {
        NewPipeline->PipeDiameter = Diameter;
        NewPipeline->PipelineType = Type;
        PlacedPipelines.Add(NewPipeline);

        UE_LOG(LogTemp, Log, TEXT("Created new pipeline"));
    }

    return NewPipeline;
}

void UEquipmentManagerSubsystem::RemovePipeline(APipelineSystem* Pipeline)
{
    if (!Pipeline)
    {
        return;
    }

    // Mettre à jour les états de connexion des équipements
    if (Pipeline->StartEquipment)
    {
        FConnectionPoint* StartPoint = Pipeline->StartEquipment->GetConnectionPointByName(Pipeline->StartConnectionPoint);
        if (StartPoint)
        {
            StartPoint->bIsConnected = false;
            StartPoint->ConnectedTo = nullptr;
        }
    }

    if (Pipeline->EndEquipment)
    {
        FConnectionPoint* EndPoint = Pipeline->EndEquipment->GetConnectionPointByName(Pipeline->EndConnectionPoint);
        if (EndPoint)
        {
            EndPoint->bIsConnected = false;
            EndPoint->ConnectedTo = nullptr;
        }
    }

    PlacedPipelines.Remove(Pipeline);
    Pipeline->Destroy();

    UE_LOG(LogTemp, Log, TEXT("Removed pipeline"));
}

TArray<AIndustrialEquipmentBase*> UEquipmentManagerSubsystem::GetEquipmentInRadius(const FVector& Center, float Radius)
{
    TArray<AIndustrialEquipmentBase*> NearbyEquipment;

    for (AIndustrialEquipmentBase* Equipment : PlacedEquipment)
    {
        if (Equipment && Equipment->bIsPlaced)
        {
            float Distance = FVector::Dist(Equipment->GetActorLocation(), Center);
            if (Distance <= Radius)
            {
                NearbyEquipment.Add(Equipment);
            }
        }
    }

    return NearbyEquipment;
}

float UEquipmentManagerSubsystem::GetTotalPowerConsumption() const
{
    float TotalPower = 0.0f;

    for (const AIndustrialEquipmentBase* Equipment : PlacedEquipment)
    {
        if (Equipment && Equipment->bIsPowered)
        {
            TotalPower += Equipment->EquipmentData.PowerRequirement;
        }
    }

    return TotalPower;
}
