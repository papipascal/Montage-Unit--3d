// PipelineSystem.cpp
#include "PipelineSystem.h"
#include "Components/SplineMeshComponent.h"
#include "Components/SplineComponent.h"
#include "Kismet/KismetMathLibrary.h"

APipelineSystem::APipelineSystem()
{
    PrimaryActorTick.bCanEverTick = true;

    PipelineRoot = CreateDefaultSubobject<USceneComponent>(TEXT("PipelineRoot"));
    RootComponent = PipelineRoot;

    PipeDiameter = EPipeDiameter::DN50;
    PipelineType = EConnectionType::Hydraulic;
    bIsBeingPlaced = false;

    StartEquipment = nullptr;
    EndEquipment = nullptr;
}

void APipelineSystem::BeginPlay()
{
    Super::BeginPlay();
}

void APipelineSystem::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void APipelineSystem::StartPipeline(AIndustrialEquipmentBase* Equipment, FName ConnectionPointName)
{
    if (!Equipment || !Equipment->bIsPlaced)
    {
        UE_LOG(LogTemp, Warning, TEXT("Cannot start pipeline from unplaced equipment"));
        return;
    }

    FConnectionPoint* ConnectionPoint = Equipment->GetConnectionPointByName(ConnectionPointName);
    if (!ConnectionPoint)
    {
        UE_LOG(LogTemp, Warning, TEXT("Connection point not found: %s"), *ConnectionPointName.ToString());
        return;
    }

    if (ConnectionPoint->bIsConnected)
    {
        UE_LOG(LogTemp, Warning, TEXT("Connection point already connected"));
        return;
    }

    StartEquipment = Equipment;
    StartConnectionPoint = ConnectionPointName;
    PipelineType = ConnectionPoint->ConnectionType;
    bIsBeingPlaced = true;

    // Point de départ dans l'espace monde
    FVector WorldStartPoint = Equipment->GetActorTransform().TransformPosition(ConnectionPoint->RelativeLocation);
    PathPoints.Empty();
    PathPoints.Add(WorldStartPoint);

    UE_LOG(LogTemp, Log, TEXT("Pipeline started from %s at point %s"), 
        *Equipment->EquipmentData.EquipmentName, *ConnectionPointName.ToString());
}

void APipelineSystem::AddPathPoint(const FVector& Point)
{
    if (!bIsBeingPlaced) return;

    PathPoints.Add(Point);
    UpdatePipelineVisuals();

    UE_LOG(LogTemp, Log, TEXT("Added path point at %s. Total points: %d"), 
        *Point.ToString(), PathPoints.Num());
}

bool APipelineSystem::CompletePipeline(AIndustrialEquipmentBase* Equipment, FName ConnectionPointName)
{
    if (!bIsBeingPlaced || !Equipment || !StartEquipment)
    {
        UE_LOG(LogTemp, Warning, TEXT("Cannot complete pipeline: invalid state"));
        return false;
    }

    if (!ValidateConnection(Equipment, ConnectionPointName))
    {
        return false;
    }

    FConnectionPoint* EndPoint = Equipment->GetConnectionPointByName(ConnectionPointName);
    if (!EndPoint)
    {
        return false;
    }

    // Ajouter le point final
    FVector WorldEndPoint = Equipment->GetActorTransform().TransformPosition(EndPoint->RelativeLocation);
    PathPoints.Add(WorldEndPoint);

    // Finaliser le pipeline
    EndEquipment = Equipment;
    EndConnectionPoint = ConnectionPointName;
    bIsBeingPlaced = false;

    // Mettre à jour les états de connexion
    FConnectionPoint* StartPoint = StartEquipment->GetConnectionPointByName(StartConnectionPoint);
    if (StartPoint)
    {
        StartPoint->bIsConnected = true;
        StartPoint->ConnectedTo = EndEquipment;
    }

    EndPoint->bIsConnected = true;
    EndPoint->ConnectedTo = StartEquipment;

    // Créer les visuels finaux
    UpdatePipelineVisuals();

    UE_LOG(LogTemp, Log, TEXT("Pipeline completed: %s -> %s"), 
        *StartEquipment->EquipmentData.EquipmentName,
        *EndEquipment->EquipmentData.EquipmentName);

    return true;
}

void APipelineSystem::CancelPipeline()
{
    PathPoints.Empty();
    ClearPipelineVisuals();
    
    StartEquipment = nullptr;
    EndEquipment = nullptr;
    StartConnectionPoint = NAME_None;
    EndConnectionPoint = NAME_None;
    bIsBeingPlaced = false;

    UE_LOG(LogTemp, Log, TEXT("Pipeline cancelled"));
}

void APipelineSystem::UpdatePreviewToPoint(const FVector& Point)
{
    if (!bIsBeingPlaced || PathPoints.Num() == 0) return;

    // Créer un aperçu temporaire jusqu'au point de la souris
    TArray<FVector> PreviewPoints = PathPoints;
    PreviewPoints.Add(Point);

    // Effacer et recréer les visuels
    ClearPipelineVisuals();
    
    for (int32 i = 0; i < PreviewPoints.Num() - 1; ++i)
    {
        CreatePipeSegment(PreviewPoints[i], PreviewPoints[i + 1]);
    }
}

float APipelineSystem::GetDiameterInMeters() const
{
    switch (PipeDiameter)
    {
        case EPipeDiameter::DN25: return 0.025f;
        case EPipeDiameter::DN50: return 0.050f;
        case EPipeDiameter::DN80: return 0.080f;
        case EPipeDiameter::DN100: return 0.100f;
        case EPipeDiameter::DN150: return 0.150f;
        case EPipeDiameter::DN200: return 0.200f;
        default: return 0.050f;
    }
}

float APipelineSystem::GetTotalPipelineLength() const
{
    float TotalLength = 0.0f;

    for (int32 i = 0; i < PathPoints.Num() - 1; ++i)
    {
        TotalLength += FVector::Dist(PathPoints[i], PathPoints[i + 1]);
    }

    return TotalLength / 100.0f; // Convertir en mètres (Unreal est en cm)
}

bool APipelineSystem::ValidateConnection(AIndustrialEquipmentBase* Equipment, FName ConnectionPointName)
{
    if (!Equipment || !Equipment->bIsPlaced)
    {
        UE_LOG(LogTemp, Warning, TEXT("Target equipment is not placed"));
        return false;
    }

    if (Equipment == StartEquipment)
    {
        UE_LOG(LogTemp, Warning, TEXT("Cannot connect equipment to itself"));
        return false;
    }

    FConnectionPoint* ConnectionPoint = Equipment->GetConnectionPointByName(ConnectionPointName);
    if (!ConnectionPoint)
    {
        UE_LOG(LogTemp, Warning, TEXT("Connection point not found"));
        return false;
    }

    if (ConnectionPoint->bIsConnected)
    {
        UE_LOG(LogTemp, Warning, TEXT("Connection point already connected"));
        return false;
    }

    if (ConnectionPoint->ConnectionType != PipelineType)
    {
        UE_LOG(LogTemp, Warning, TEXT("Connection type mismatch"));
        return false;
    }

    return true;
}

void APipelineSystem::CreatePipeSegment(const FVector& Start, const FVector& End)
{
    if (!PipeMesh) return;

    USplineMeshComponent* SplineMesh = CreateSplineMeshComponent();
    if (!SplineMesh) return;

    // Configuration du spline mesh
    SplineMesh->SetStartAndEnd(Start, FVector::ZeroVector, End, FVector::ZeroVector);
    
    // Appliquer le matériau approprié
    if (PipelineType == EConnectionType::Electric && ElectricalCableMaterial)
    {
        SplineMesh->SetMaterial(0, ElectricalCableMaterial);
    }
    else if (PipeMaterial)
    {
        SplineMesh->SetMaterial(0, PipeMaterial);
    }

    // Ajuster l'échelle selon le diamètre
    float Scale = GetDiameterInMeters() * 100.0f; // Convertir en cm
    SplineMesh->SetStartScale(FVector2D(Scale, Scale));
    SplineMesh->SetEndScale(FVector2D(Scale, Scale));

    // Ajouter aux segments
    FPipeSegment Segment;
    Segment.StartPoint = Start;
    Segment.EndPoint = End;
    Segment.Diameter = GetDiameterInMeters();
    Segment.MeshComponent = SplineMesh;
    PipeSegments.Add(Segment);
}

void APipelineSystem::ClearPipelineVisuals()
{
    for (FPipeSegment& Segment : PipeSegments)
    {
        if (Segment.MeshComponent)
        {
            Segment.MeshComponent->DestroyComponent();
        }
    }
    PipeSegments.Empty();
}

void APipelineSystem::UpdatePipelineVisuals()
{
    ClearPipelineVisuals();

    for (int32 i = 0; i < PathPoints.Num() - 1; ++i)
    {
        CreatePipeSegment(PathPoints[i], PathPoints[i + 1]);
    }
}

USplineMeshComponent* APipelineSystem::CreateSplineMeshComponent()
{
    USplineMeshComponent* SplineMesh = NewObject<USplineMeshComponent>(this);
    if (SplineMesh)
    {
        SplineMesh->RegisterComponent();
        SplineMesh->AttachToComponent(PipelineRoot, FAttachmentTransformRules::KeepWorldTransform);
        SplineMesh->SetStaticMesh(PipeMesh);
        SplineMesh->SetMobility(EComponentMobility::Movable);
        SplineMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }
    return SplineMesh;
}
