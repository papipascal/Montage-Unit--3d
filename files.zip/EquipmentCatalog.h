// EquipmentCatalog.h
#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "IndustrialEquipmentBase.h"
#include "EquipmentCatalog.generated.h"

/**
 * Catalogue d'équipements industriels disponibles
 */
UCLASS(BlueprintType)
class UEquipmentCatalog : public UDataAsset
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Catalog")
    TArray<FEquipmentData> AvailableEquipment;

    UFUNCTION(BlueprintCallable, Category = "Catalog")
    TArray<FEquipmentData> GetEquipmentByType(EEquipmentType Type) const;

    UFUNCTION(BlueprintCallable, Category = "Catalog")
    FEquipmentData GetEquipmentByName(const FString& Name) const;

    UFUNCTION(BlueprintCallable, Category = "Catalog")
    TArray<FEquipmentData> GetAllPumps() const;

    UFUNCTION(BlueprintCallable, Category = "Catalog")
    TArray<FEquipmentData> GetAllPressureVessels() const;
};

/**
 * Subsystem pour gérer le catalogue et le spawning d'équipements
 */
UCLASS()
class UEquipmentManagerSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    virtual void Deinitialize() override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Equipment")
    UEquipmentCatalog* DefaultCatalog;

    UPROPERTY(BlueprintReadOnly, Category = "Equipment")
    TArray<AIndustrialEquipmentBase*> PlacedEquipment;

    UPROPERTY(BlueprintReadOnly, Category = "Equipment")
    TArray<class APipelineSystem*> PlacedPipelines;

    // Fonctions de gestion
    UFUNCTION(BlueprintCallable, Category = "Equipment")
    AIndustrialEquipmentBase* SpawnEquipmentFromCatalog(const FString& EquipmentName, const FVector& Location);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    void RemoveEquipment(AIndustrialEquipmentBase* Equipment);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    APipelineSystem* CreatePipeline(EPipeDiameter Diameter, EConnectionType Type);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    void RemovePipeline(APipelineSystem* Pipeline);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    TArray<AIndustrialEquipmentBase*> GetEquipmentInRadius(const FVector& Center, float Radius);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    float GetTotalPowerConsumption() const;

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    int32 GetEquipmentCount() const { return PlacedEquipment.Num(); }

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    int32 GetPipelineCount() const { return PlacedPipelines.Num(); }
};
