// IndustrialEquipmentBase.h
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "IndustrialEquipmentBase.generated.h"

UENUM(BlueprintType)
enum class EEquipmentType : uint8
{
    Pump UMETA(DisplayName = "Pompe"),
    PressureVessel UMETA(DisplayName = "Équipement sous pression"),
    Tank UMETA(DisplayName = "Réservoir"),
    Compressor UMETA(DisplayName = "Compresseur")
};

UENUM(BlueprintType)
enum class EConnectionType : uint8
{
    Hydraulic UMETA(DisplayName = "Hydraulique"),
    Electric UMETA(DisplayName = "Électrique"),
    Pneumatic UMETA(DisplayName = "Pneumatique")
};

USTRUCT(BlueprintType)
struct FConnectionPoint
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FName SocketName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EConnectionType ConnectionType;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float Diameter; // En mètres pour tuyauterie, calibre pour électrique

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector RelativeLocation;

    UPROPERTY(BlueprintReadWrite)
    bool bIsConnected;

    UPROPERTY(BlueprintReadWrite)
    AActor* ConnectedTo;

    FConnectionPoint()
        : SocketName(NAME_None)
        , ConnectionType(EConnectionType::Hydraulic)
        , Diameter(0.05f)
        , RelativeLocation(FVector::ZeroVector)
        , bIsConnected(false)
        , ConnectedTo(nullptr)
    {}
};

USTRUCT(BlueprintType)
struct FEquipmentData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FString EquipmentName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EEquipmentType EquipmentType;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float Height; // en mètres

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float Diameter; // en mètres

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float Weight; // en kg

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float PowerRequirement; // en kW

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    UStaticMesh* Mesh;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TArray<FConnectionPoint> ConnectionPoints;

    FEquipmentData()
        : EquipmentName(TEXT("Equipment"))
        , EquipmentType(EEquipmentType::Pump)
        , Height(3.0f)
        , Diameter(1.5f)
        , Weight(500.0f)
        , PowerRequirement(10.0f)
        , Mesh(nullptr)
    {}
};

UCLASS()
class AIndustrialEquipmentBase : public AActor
{
    GENERATED_BODY()

public:
    AIndustrialEquipmentBase();

protected:
    virtual void BeginPlay() override;

public:
    virtual void Tick(float DeltaTime) override;

    // Composants
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    UStaticMeshComponent* EquipmentMesh;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    USceneComponent* ConnectionPointsRoot;

    // Données de l'équipement
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Equipment")
    FEquipmentData EquipmentData;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Equipment")
    bool bIsPlaced;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Equipment")
    bool bIsPowered;

    // Matériaux pour le feedback visuel
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual")
    UMaterialInterface* ValidPlacementMaterial;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual")
    UMaterialInterface* InvalidPlacementMaterial;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Visual")
    UMaterialInterface* NormalMaterial;

    // Fonctions
    UFUNCTION(BlueprintCallable, Category = "Equipment")
    void SetPlacementMode(bool bInPlacementMode);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    bool CanBePlacedAt(const FVector& Location);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    void PlaceEquipment(const FVector& Location, const FRotator& Rotation);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    TArray<FConnectionPoint> GetAvailableConnectionPoints(EConnectionType Type);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    FConnectionPoint* GetConnectionPointByName(FName SocketName);

    UFUNCTION(BlueprintCallable, Category = "Equipment")
    void InitializeFromData(const FEquipmentData& Data);

private:
    void UpdateVisualFeedback(bool bValidPlacement);
    void CreateConnectionPointComponents();

    bool bInPlacementMode;
};
