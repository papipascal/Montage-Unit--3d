// IndustrialPlayerController.h
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "IndustrialEquipmentBase.h"
#include "PipelineSystem.h"
#include "IndustrialPlayerController.generated.h"

UENUM(BlueprintType)
enum class EPlacementMode : uint8
{
    None UMETA(DisplayName = "Aucun"),
    PlacingEquipment UMETA(DisplayName = "Placement Équipement"),
    PlacingPipeline UMETA(DisplayName = "Placement Tuyauterie"),
    SelectingEquipment UMETA(DisplayName = "Sélection")
};

/**
 * Player Controller pour gérer le placement d'équipements et de tuyauteries
 */
UCLASS()
class AIndustrialPlayerController : public APlayerController
{
    GENERATED_BODY()

public:
    AIndustrialPlayerController();

protected:
    virtual void BeginPlay() override;
    virtual void SetupInputComponent() override;

public:
    virtual void Tick(float DeltaTime) override;

    // Mode de placement actuel
    UPROPERTY(BlueprintReadOnly, Category = "Placement")
    EPlacementMode CurrentMode;

    // Équipement en cours de placement
    UPROPERTY(BlueprintReadOnly, Category = "Placement")
    AIndustrialEquipmentBase* EquipmentBeingPlaced;

    // Pipeline en cours de création
    UPROPERTY(BlueprintReadOnly, Category = "Placement")
    APipelineSystem* PipelineBeingPlaced;

    // Équipement sélectionné
    UPROPERTY(BlueprintReadOnly, Category = "Placement")
    AIndustrialEquipmentBase* SelectedEquipment;

    // Paramètres de placement
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Placement")
    float PlacementGridSize;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Placement")
    bool bSnapToGrid;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Placement")
    float MaxPlacementDistance;

    // UI et Feedback
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<class UUserWidget> CatalogWidgetClass;

    UPROPERTY(BlueprintReadOnly, Category = "UI")
    class UUserWidget* CatalogWidget;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<class UUserWidget> ConnectionMenuWidgetClass;

    // Fonctions de placement d'équipement
    UFUNCTION(BlueprintCallable, Category = "Placement")
    void StartPlacingEquipment(const FString& EquipmentName);

    UFUNCTION(BlueprintCallable, Category = "Placement")
    void ConfirmEquipmentPlacement();

    UFUNCTION(BlueprintCallable, Category = "Placement")
    void CancelEquipmentPlacement();

    UFUNCTION(BlueprintCallable, Category = "Placement")
    void RotateEquipment(float Angle);

    // Fonctions de placement de tuyauterie
    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void StartPlacingPipeline(EPipeDiameter Diameter, EConnectionType Type);

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void AddPipelinePoint();

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void CompletePipelinePlacement();

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void CancelPipelinePlacement();

    // Fonctions de sélection
    UFUNCTION(BlueprintCallable, Category = "Selection")
    void SelectEquipmentUnderCursor();

    UFUNCTION(BlueprintCallable, Category = "Selection")
    void DeselectEquipment();

    UFUNCTION(BlueprintCallable, Category = "Selection")
    void DeleteSelectedEquipment();

    // Fonctions UI
    UFUNCTION(BlueprintCallable, Category = "UI")
    void ToggleCatalog();

    UFUNCTION(BlueprintCallable, Category = "UI")
    void ShowConnectionMenu(AIndustrialEquipmentBase* Equipment);

    UFUNCTION(BlueprintCallable, Category = "UI")
    void HideConnectionMenu();

    // Utilitaires
    UFUNCTION(BlueprintCallable, Category = "Placement")
    FVector GetCursorWorldLocation() const;

    UFUNCTION(BlueprintCallable, Category = "Placement")
    FVector SnapToGrid(const FVector& Location) const;

    UFUNCTION(BlueprintCallable, Category = "Placement")
    AIndustrialEquipmentBase* GetEquipmentUnderCursor() const;

private:
    // Input handlers
    void OnLeftMouseClick();
    void OnRightMouseClick();
    void OnRotateClockwise();
    void OnRotateCounterClockwise();
    void OnCancelAction();
    void OnDeleteKey();

    // Helper functions
    void UpdateEquipmentPlacement();
    void UpdatePipelinePreview();
    bool TraceForPlacement(FHitResult& OutHit) const;

    class UEquipmentManagerSubsystem* EquipmentManager;
};
