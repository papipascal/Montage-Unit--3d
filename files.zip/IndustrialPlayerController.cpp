// IndustrialPlayerController.cpp
#include "IndustrialPlayerController.h"
#include "EquipmentCatalog.h"
#include "Blueprint/UserWidget.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"

AIndustrialPlayerController::AIndustrialPlayerController()
{
    PrimaryActorTick.bCanEverTick = true;

    CurrentMode = EPlacementMode::None;
    EquipmentBeingPlaced = nullptr;
    PipelineBeingPlaced = nullptr;
    SelectedEquipment = nullptr;

    PlacementGridSize = 50.0f; // 50cm
    bSnapToGrid = true;
    MaxPlacementDistance = 10000.0f; // 100m

    bShowMouseCursor = true;
    bEnableClickEvents = true;
    bEnableMouseOverEvents = true;
}

void AIndustrialPlayerController::BeginPlay()
{
    Super::BeginPlay();

    // Obtenir le subsystem de gestion d'équipement
    EquipmentManager = GetWorld()->GetSubsystem<UEquipmentManagerSubsystem>();

    // Créer le widget de catalogue si spécifié
    if (CatalogWidgetClass)
    {
        CatalogWidget = CreateWidget<UUserWidget>(this, CatalogWidgetClass);
    }
}

void AIndustrialPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();

    if (InputComponent)
    {
        // Mouse inputs
        InputComponent->BindAction("LeftClick", IE_Pressed, this, &AIndustrialPlayerController::OnLeftMouseClick);
        InputComponent->BindAction("RightClick", IE_Pressed, this, &AIndustrialPlayerController::OnRightMouseClick);

        // Keyboard inputs
        InputComponent->BindAction("RotateClockwise", IE_Pressed, this, &AIndustrialPlayerController::OnRotateClockwise);
        InputComponent->BindAction("RotateCounterClockwise", IE_Pressed, this, &AIndustrialPlayerController::OnRotateCounterClockwise);
        InputComponent->BindAction("Cancel", IE_Pressed, this, &AIndustrialPlayerController::OnCancelAction);
        InputComponent->BindAction("Delete", IE_Pressed, this, &AIndustrialPlayerController::OnDeleteKey);
    }
}

void AIndustrialPlayerController::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    switch (CurrentMode)
    {
        case EPlacementMode::PlacingEquipment:
            UpdateEquipmentPlacement();
            break;

        case EPlacementMode::PlacingPipeline:
            UpdatePipelinePreview();
            break;

        default:
            break;
    }
}

void AIndustrialPlayerController::StartPlacingEquipment(const FString& EquipmentName)
{
    if (!EquipmentManager)
    {
        UE_LOG(LogTemp, Error, TEXT("Equipment Manager not found"));
        return;
    }

    // Annuler toute action en cours
    if (CurrentMode != EPlacementMode::None)
    {
        OnCancelAction();
    }

    // Spawner l'équipement
    FVector SpawnLocation = GetCursorWorldLocation();
    EquipmentBeingPlaced = EquipmentManager->SpawnEquipmentFromCatalog(EquipmentName, SpawnLocation);

    if (EquipmentBeingPlaced)
    {
        CurrentMode = EPlacementMode::PlacingEquipment;
        UE_LOG(LogTemp, Log, TEXT("Started placing equipment: %s"), *EquipmentName);
    }
}

void AIndustrialPlayerController::ConfirmEquipmentPlacement()
{
    if (!EquipmentBeingPlaced || CurrentMode != EPlacementMode::PlacingEquipment)
    {
        return;
    }

    FVector PlacementLocation = EquipmentBeingPlaced->GetActorLocation();
    FRotator PlacementRotation = EquipmentBeingPlaced->GetActorRotation();

    if (EquipmentBeingPlaced->CanBePlacedAt(PlacementLocation))
    {
        EquipmentBeingPlaced->PlaceEquipment(PlacementLocation, PlacementRotation);
        EquipmentBeingPlaced = nullptr;
        CurrentMode = EPlacementMode::None;

        UE_LOG(LogTemp, Log, TEXT("Equipment placed successfully"));
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("Cannot place equipment at this location"));
    }
}

void AIndustrialPlayerController::CancelEquipmentPlacement()
{
    if (EquipmentBeingPlaced)
    {
        EquipmentManager->RemoveEquipment(EquipmentBeingPlaced);
        EquipmentBeingPlaced = nullptr;
    }

    CurrentMode = EPlacementMode::None;
    UE_LOG(LogTemp, Log, TEXT("Equipment placement cancelled"));
}

void AIndustrialPlayerController::RotateEquipment(float Angle)
{
    if (EquipmentBeingPlaced)
    {
        FRotator NewRotation = EquipmentBeingPlaced->GetActorRotation();
        NewRotation.Yaw += Angle;
        EquipmentBeingPlaced->SetActorRotation(NewRotation);
    }
}

void AIndustrialPlayerController::StartPlacingPipeline(EPipeDiameter Diameter, EConnectionType Type)
{
    if (!EquipmentManager)
    {
        return;
    }

    // Annuler toute action en cours
    if (CurrentMode != EPlacementMode::None)
    {
        OnCancelAction();
    }

    // Créer un nouveau pipeline
    PipelineBeingPlaced = EquipmentManager->CreatePipeline(Diameter, Type);

    if (PipelineBeingPlaced)
    {
        CurrentMode = EPlacementMode::PlacingPipeline;
        UE_LOG(LogTemp, Log, TEXT("Started placing pipeline"));
    }
}

void AIndustrialPlayerController::AddPipelinePoint()
{
    if (!PipelineBeingPlaced || CurrentMode != EPlacementMode::PlacingPipeline)
    {
        return;
    }

    FVector PointLocation = GetCursorWorldLocation();

    if (!PipelineBeingPlaced->bIsBeingPlaced)
    {
        // Premier point - doit être sur un équipement
        AIndustrialEquipmentBase* Equipment = GetEquipmentUnderCursor();
        if (Equipment && Equipment->bIsPlaced)
        {
            // Trouver le point de connexion le plus proche
            TArray<FConnectionPoint> AvailablePoints = Equipment->GetAvailableConnectionPoints(PipelineBeingPlaced->PipelineType);
            
            if (AvailablePoints.Num() > 0)
            {
                PipelineBeingPlaced->StartPipeline(Equipment, AvailablePoints[0].SocketName);
            }
        }
    }
    else
    {
        // Point intermédiaire
        if (bSnapToGrid)
        {
            PointLocation = SnapToGrid(PointLocation);
        }
        PipelineBeingPlaced->AddPathPoint(PointLocation);
    }
}

void AIndustrialPlayerController::CompletePipelinePlacement()
{
    if (!PipelineBeingPlaced || CurrentMode != EPlacementMode::PlacingPipeline)
    {
        return;
    }

    // Doit finir sur un équipement
    AIndustrialEquipmentBase* Equipment = GetEquipmentUnderCursor();
    if (Equipment && Equipment->bIsPlaced)
    {
        TArray<FConnectionPoint> AvailablePoints = Equipment->GetAvailableConnectionPoints(PipelineBeingPlaced->PipelineType);
        
        if (AvailablePoints.Num() > 0)
        {
            if (PipelineBeingPlaced->CompletePipeline(Equipment, AvailablePoints[0].SocketName))
            {
                PipelineBeingPlaced = nullptr;
                CurrentMode = EPlacementMode::None;
                UE_LOG(LogTemp, Log, TEXT("Pipeline completed"));
                return;
            }
        }
    }

    UE_LOG(LogTemp, Warning, TEXT("Cannot complete pipeline - no valid connection point"));
}

void AIndustrialPlayerController::CancelPipelinePlacement()
{
    if (PipelineBeingPlaced)
    {
        EquipmentManager->RemovePipeline(PipelineBeingPlaced);
        PipelineBeingPlaced = nullptr;
    }

    CurrentMode = EPlacementMode::None;
    UE_LOG(LogTemp, Log, TEXT("Pipeline placement cancelled"));
}

void AIndustrialPlayerController::SelectEquipmentUnderCursor()
{
    AIndustrialEquipmentBase* Equipment = GetEquipmentUnderCursor();
    
    if (Equipment && Equipment->bIsPlaced)
    {
        DeselectEquipment(); // Désélectionner l'ancien
        SelectedEquipment = Equipment;
        CurrentMode = EPlacementMode::SelectingEquipment;
        
        // Afficher le menu de connexion
        ShowConnectionMenu(Equipment);
        
        UE_LOG(LogTemp, Log, TEXT("Selected equipment: %s"), *Equipment->EquipmentData.EquipmentName);
    }
}

void AIndustrialPlayerController::DeselectEquipment()
{
    if (SelectedEquipment)
    {
        SelectedEquipment = nullptr;
        HideConnectionMenu();
        
        if (CurrentMode == EPlacementMode::SelectingEquipment)
        {
            CurrentMode = EPlacementMode::None;
        }
    }
}

void AIndustrialPlayerController::DeleteSelectedEquipment()
{
    if (SelectedEquipment && EquipmentManager)
    {
        EquipmentManager->RemoveEquipment(SelectedEquipment);
        SelectedEquipment = nullptr;
        CurrentMode = EPlacementMode::None;
        
        UE_LOG(LogTemp, Log, TEXT("Equipment deleted"));
    }
}

void AIndustrialPlayerController::ToggleCatalog()
{
    if (CatalogWidget)
    {
        if (CatalogWidget->IsInViewport())
        {
            CatalogWidget->RemoveFromParent();
        }
        else
        {
            CatalogWidget->AddToViewport();
        }
    }
}

void AIndustrialPlayerController::ShowConnectionMenu(AIndustrialEquipmentBase* Equipment)
{
    // À implémenter avec votre widget UI
    // Afficher les points de connexion disponibles
}

void AIndustrialPlayerController::HideConnectionMenu()
{
    // À implémenter avec votre widget UI
}

FVector AIndustrialPlayerController::GetCursorWorldLocation() const
{
    FHitResult HitResult;
    if (TraceForPlacement(HitResult))
    {
        return HitResult.Location;
    }

    return FVector::ZeroVector;
}

FVector AIndustrialPlayerController::SnapToGrid(const FVector& Location) const
{
    if (!bSnapToGrid)
    {
        return Location;
    }

    FVector SnappedLocation;
    SnappedLocation.X = FMath::RoundToFloat(Location.X / PlacementGridSize) * PlacementGridSize;
    SnappedLocation.Y = FMath::RoundToFloat(Location.Y / PlacementGridSize) * PlacementGridSize;
    SnappedLocation.Z = Location.Z;

    return SnappedLocation;
}

AIndustrialEquipmentBase* AIndustrialPlayerController::GetEquipmentUnderCursor() const
{
    FHitResult HitResult;
    GetHitResultUnderCursor(ECC_Visibility, false, HitResult);

    if (HitResult.GetActor())
    {
        return Cast<AIndustrialEquipmentBase>(HitResult.GetActor());
    }

    return nullptr;
}

void AIndustrialPlayerController::OnLeftMouseClick()
{
    switch (CurrentMode)
    {
        case EPlacementMode::PlacingEquipment:
            ConfirmEquipmentPlacement();
            break;

        case EPlacementMode::PlacingPipeline:
            if (PipelineBeingPlaced && !PipelineBeingPlaced->bIsBeingPlaced)
            {
                AddPipelinePoint(); // Premier point
            }
            else
            {
                CompletePipelinePlacement(); // Dernier point
            }
            break;

        case EPlacementMode::None:
            SelectEquipmentUnderCursor();
            break;

        default:
            break;
    }
}

void AIndustrialPlayerController::OnRightMouseClick()
{
    if (CurrentMode == EPlacementMode::PlacingPipeline && PipelineBeingPlaced && PipelineBeingPlaced->bIsBeingPlaced)
    {
        // Ajouter un point intermédiaire
        AddPipelinePoint();
    }
    else
    {
        OnCancelAction();
    }
}

void AIndustrialPlayerController::OnRotateClockwise()
{
    RotateEquipment(45.0f);
}

void AIndustrialPlayerController::OnRotateCounterClockwise()
{
    RotateEquipment(-45.0f);
}

void AIndustrialPlayerController::OnCancelAction()
{
    switch (CurrentMode)
    {
        case EPlacementMode::PlacingEquipment:
            CancelEquipmentPlacement();
            break;

        case EPlacementMode::PlacingPipeline:
            CancelPipelinePlacement();
            break;

        case EPlacementMode::SelectingEquipment:
            DeselectEquipment();
            break;

        default:
            break;
    }
}

void AIndustrialPlayerController::OnDeleteKey()
{
    if (CurrentMode == EPlacementMode::SelectingEquipment)
    {
        DeleteSelectedEquipment();
    }
}

void AIndustrialPlayerController::UpdateEquipmentPlacement()
{
    if (!EquipmentBeingPlaced)
    {
        return;
    }

    FVector CursorLocation = GetCursorWorldLocation();

    if (bSnapToGrid)
    {
        CursorLocation = SnapToGrid(CursorLocation);
    }

    EquipmentBeingPlaced->SetActorLocation(CursorLocation);
}

void AIndustrialPlayerController::UpdatePipelinePreview()
{
    if (!PipelineBeingPlaced || !PipelineBeingPlaced->bIsBeingPlaced)
    {
        return;
    }

    FVector CursorLocation = GetCursorWorldLocation();
    PipelineBeingPlaced->UpdatePreviewToPoint(CursorLocation);
}

bool AIndustrialPlayerController::TraceForPlacement(FHitResult& OutHit) const
{
    FVector WorldLocation, WorldDirection;
    if (DeprojectMousePositionToWorld(WorldLocation, WorldDirection))
    {
        FVector Start = WorldLocation;
        FVector End = WorldLocation + (WorldDirection * MaxPlacementDistance);

        FCollisionQueryParams QueryParams;
        QueryParams.AddIgnoredActor(EquipmentBeingPlaced);

        return GetWorld()->LineTraceSingleByChannel(
            OutHit,
            Start,
            End,
            ECC_Visibility,
            QueryParams
        );
    }

    return false;
}
