// IndustrialEquipmentBase.cpp
#include "IndustrialEquipmentBase.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"

AIndustrialEquipmentBase::AIndustrialEquipmentBase()
{
    PrimaryActorTick.bCanEverTick = true;

    // Créer le root component
    RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

    // Créer le mesh de l'équipement
    EquipmentMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("EquipmentMesh"));
    EquipmentMesh->SetupAttachment(RootComponent);
    EquipmentMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    EquipmentMesh->SetCollisionResponseToAllChannels(ECR_Block);

    // Créer le root pour les points de connexion
    ConnectionPointsRoot = CreateDefaultSubobject<USceneComponent>(TEXT("ConnectionPointsRoot"));
    ConnectionPointsRoot->SetupAttachment(RootComponent);

    bIsPlaced = false;
    bIsPowered = false;
    bInPlacementMode = false;
}

void AIndustrialEquipmentBase::BeginPlay()
{
    Super::BeginPlay();
    
    CreateConnectionPointComponents();
}

void AIndustrialEquipmentBase::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    // Si en mode placement, vérifier la validité de la position
    if (bInPlacementMode && !bIsPlaced)
    {
        bool bValidPlacement = CanBePlacedAt(GetActorLocation());
        UpdateVisualFeedback(bValidPlacement);
    }
}

void AIndustrialEquipmentBase::SetPlacementMode(bool bInPlacementMode)
{
    this->bInPlacementMode = bInPlacementMode;
    
    if (bInPlacementMode)
    {
        // Désactiver la physique pendant le placement
        EquipmentMesh->SetSimulatePhysics(false);
        EquipmentMesh->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    }
}

bool AIndustrialEquipmentBase::CanBePlacedAt(const FVector& Location)
{
    if (!GetWorld()) return false;

    // Vérifier qu'on est sur une plateforme
    FVector StartTrace = Location;
    FVector EndTrace = Location - FVector(0, 0, 200.0f); // 2m vers le bas

    FHitResult HitResult;
    FCollisionQueryParams QueryParams;
    QueryParams.AddIgnoredActor(this);

    bool bHitGround = GetWorld()->LineTraceSingleByChannel(
        HitResult,
        StartTrace,
        EndTrace,
        ECC_Visibility,
        QueryParams
    );

    if (!bHitGround)
    {
        return false;
    }

    // Vérifier qu'il n'y a pas d'overlap avec d'autres équipements
    FVector BoxExtent = FVector(EquipmentData.Diameter * 50.0f, EquipmentData.Diameter * 50.0f, EquipmentData.Height * 50.0f);
    
    TArray<FOverlapResult> Overlaps;
    FCollisionShape CollisionBox = FCollisionShape::MakeBox(BoxExtent);
    
    bool bHasOverlap = GetWorld()->OverlapMultiByChannel(
        Overlaps,
        Location,
        FQuat::Identity,
        ECC_WorldDynamic,
        CollisionBox,
        QueryParams
    );

    // Si overlap avec d'autres équipements, invalide
    for (const FOverlapResult& Overlap : Overlaps)
    {
        if (Overlap.GetActor() && Overlap.GetActor()->IsA<AIndustrialEquipmentBase>())
        {
            return false;
        }
    }

    return true;
}

void AIndustrialEquipmentBase::PlaceEquipment(const FVector& Location, const FRotator& Rotation)
{
    if (!CanBePlacedAt(Location))
    {
        UE_LOG(LogTemp, Warning, TEXT("Cannot place equipment at this location"));
        return;
    }

    SetActorLocation(Location);
    SetActorRotation(Rotation);
    
    bIsPlaced = true;
    bInPlacementMode = false;

    // Réactiver les collisions normales
    EquipmentMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    
    // Restaurer le matériau normal
    if (NormalMaterial)
    {
        EquipmentMesh->SetMaterial(0, NormalMaterial);
    }

    UE_LOG(LogTemp, Log, TEXT("Equipment placed successfully: %s"), *EquipmentData.EquipmentName);
}

TArray<FConnectionPoint> AIndustrialEquipmentBase::GetAvailableConnectionPoints(EConnectionType Type)
{
    TArray<FConnectionPoint> AvailablePoints;

    for (FConnectionPoint& Point : EquipmentData.ConnectionPoints)
    {
        if (Point.ConnectionType == Type && !Point.bIsConnected)
        {
            AvailablePoints.Add(Point);
        }
    }

    return AvailablePoints;
}

FConnectionPoint* AIndustrialEquipmentBase::GetConnectionPointByName(FName SocketName)
{
    for (FConnectionPoint& Point : EquipmentData.ConnectionPoints)
    {
        if (Point.SocketName == SocketName)
        {
            return &Point;
        }
    }

    return nullptr;
}

void AIndustrialEquipmentBase::InitializeFromData(const FEquipmentData& Data)
{
    EquipmentData = Data;

    if (EquipmentMesh && Data.Mesh)
    {
        EquipmentMesh->SetStaticMesh(Data.Mesh);
    }

    CreateConnectionPointComponents();
}

void AIndustrialEquipmentBase::UpdateVisualFeedback(bool bValidPlacement)
{
    if (!EquipmentMesh) return;

    if (bValidPlacement && ValidPlacementMaterial)
    {
        EquipmentMesh->SetMaterial(0, ValidPlacementMaterial);
    }
    else if (!bValidPlacement && InvalidPlacementMaterial)
    {
        EquipmentMesh->SetMaterial(0, InvalidPlacementMaterial);
    }
}

void AIndustrialEquipmentBase::CreateConnectionPointComponents()
{
    if (!ConnectionPointsRoot) return;

    // Nettoyer les anciens composants
    TArray<USceneComponent*> Children;
    ConnectionPointsRoot->GetChildrenComponents(false, Children);
    for (USceneComponent* Child : Children)
    {
        Child->DestroyComponent();
    }

    // Créer des visualiseurs pour chaque point de connexion
    for (const FConnectionPoint& Point : EquipmentData.ConnectionPoints)
    {
        USceneComponent* PointComponent = NewObject<USceneComponent>(this);
        if (PointComponent)
        {
            PointComponent->RegisterComponent();
            PointComponent->AttachToComponent(ConnectionPointsRoot, FAttachmentTransformRules::KeepRelativeTransform);
            PointComponent->SetRelativeLocation(Point.RelativeLocation);
        }
    }
}
