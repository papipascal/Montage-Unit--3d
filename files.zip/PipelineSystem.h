// PipelineSystem.h
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "IndustrialEquipmentBase.h"
#include "PipelineSystem.generated.h"

UENUM(BlueprintType)
enum class EPipeDiameter : uint8
{
    DN25 UMETA(DisplayName = "DN25 (1 pouce)"),
    DN50 UMETA(DisplayName = "DN50 (2 pouces)"),
    DN80 UMETA(DisplayName = "DN80 (3 pouces)"),
    DN100 UMETA(DisplayName = "DN100 (4 pouces)"),
    DN150 UMETA(DisplayName = "DN150 (6 pouces)"),
    DN200 UMETA(DisplayName = "DN200 (8 pouces)")
};

USTRUCT(BlueprintType)
struct FPipeSegment
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadWrite)
    FVector StartPoint;

    UPROPERTY(BlueprintReadWrite)
    FVector EndPoint;

    UPROPERTY(BlueprintReadWrite)
    float Diameter;

    UPROPERTY(BlueprintReadWrite)
    USplineMeshComponent* MeshComponent;

    FPipeSegment()
        : StartPoint(FVector::ZeroVector)
        , EndPoint(FVector::ZeroVector)
        , Diameter(0.05f)
        , MeshComponent(nullptr)
    {}
};

UCLASS()
class APipelineSystem : public AActor
{
    GENERATED_BODY()

public:
    APipelineSystem();

protected:
    virtual void BeginPlay() override;

public:
    virtual void Tick(float DeltaTime) override;

    // Composants
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    USceneComponent* PipelineRoot;

    // Données du pipeline
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pipeline")
    EPipeDiameter PipeDiameter;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pipeline")
    EConnectionType PipelineType;

    UPROPERTY(BlueprintReadOnly, Category = "Pipeline")
    AIndustrialEquipmentBase* StartEquipment;

    UPROPERTY(BlueprintReadOnly, Category = "Pipeline")
    AIndustrialEquipmentBase* EndEquipment;

    UPROPERTY(BlueprintReadOnly, Category = "Pipeline")
    FName StartConnectionPoint;

    UPROPERTY(BlueprintReadOnly, Category = "Pipeline")
    FName EndConnectionPoint;

    // Mesh pour les tuyaux
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pipeline|Visuals")
    UStaticMesh* PipeMesh;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pipeline|Visuals")
    UMaterialInterface* PipeMaterial;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pipeline|Visuals")
    UMaterialInterface* ElectricalCableMaterial;

    // Segments du pipeline
    UPROPERTY(BlueprintReadOnly, Category = "Pipeline")
    TArray<FPipeSegment> PipeSegments;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pipeline")
    bool bIsBeingPlaced;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pipeline")
    TArray<FVector> PathPoints;

    // Fonctions principales
    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void StartPipeline(AIndustrialEquipmentBase* Equipment, FName ConnectionPointName);

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void AddPathPoint(const FVector& Point);

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    bool CompletePipeline(AIndustrialEquipmentBase* Equipment, FName ConnectionPointName);

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void CancelPipeline();

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    void UpdatePreviewToPoint(const FVector& Point);

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    float GetDiameterInMeters() const;

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    float GetTotalPipelineLength() const;

    UFUNCTION(BlueprintCallable, Category = "Pipeline")
    bool ValidateConnection(AIndustrialEquipmentBase* Equipment, FName ConnectionPointName);

private:
    void CreatePipeSegment(const FVector& Start, const FVector& End);
    void ClearPipelineVisuals();
    void UpdatePipelineVisuals();
    
    USplineMeshComponent* CreateSplineMeshComponent();
};
